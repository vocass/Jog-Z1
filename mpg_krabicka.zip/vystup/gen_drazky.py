"""G-kod pro Makera Z1: obloukove drazky v lici krabicky (omezeni chodu volicu).
Nulovy bod X0 Y0 = stred otvoru prepinace OS (vlevo), Z0 = lic panelu. Ucho krabicky smeruje k +Y (dozadu)."""
import math, sys
sys.path.insert(0, '/home/claude')
import mpg_box as B

TOOL_D = 2.0
S, F, FZ, STEPDN, SAFE = 12000, 300, 80, 0.3, 3.0
g = B.STOP_GROOVE
ox, oy = B.AXIS_SW_POS
def P(r, a, c):     # polar CW od +Y, relativne k nule
    return (c[0] - ox + r * math.sin(math.radians(a)), c[1] - oy + r * math.cos(math.radians(a)))

ops = []
for name, pos, labels in (("volic OS", B.AXIS_SW_POS, B.AXIS_LABELS), ("volic KROKU", B.STEP_SW_POS, B.STEP_LABELS)):
    a0 = labels[0][1] - g["over"]; a1 = labels[-1][1] + g["over"]
    off = (g["w"] - TOOL_D) / 2
    ops.append((name, pos, a0, a1, [g["r"] - off, g["r"] + off]))

L = []
L += [";@MKR|BEGIN", ";@MKR|SCHEMA|v=1.0.0", ";@MKR|MACHINE|id=Z1",
      ";@MKR|STOCK|type=box|x=85|y=150|z=40|material=plast (PLA/PETG)",
      ";@MKR|ORIGIN|x=stred otvoru voliče OS|y=stred otvoru voliče OS|z=lic panelu",
      ";@MKR|UNIT|value=mm", f";@MKR|MAXFEEDRATE|value={F}",
      ";@MKR|TOOL|number=1|id=|name=2mm 4-brita Flat End|type=Flat End|handlediameter=6|sticklength=0|shoulderlength=6|flutelength=6|diameter=2|tipdiameter=2|cornerradius=0|angle=0|halfAngle=0",
      ";@MKR|TIME|value=4min",
      ";@MKR|TOOLPATH|name=Drazka volic OS|tool=1", ";@MKR|TOOLPATH|name=Drazka volic KROKU|tool=1",
      ";@MKR|END",
      "; Drazky omezujici chod volicu - sirka %.1f, hloubka %.1f, polomer osy %.1f mm" % (g["w"], g["depth"], g["r"]),
      "; Nula: X0 Y0 stred otvoru voliče OS (vlevo), Z0 lic panelu. Ucho krabicky dozadu (+Y), bok rovnobezne s osou Y.",
      "; Volic KROKU je o %.1f mm vpravo (+X)." % (B.STEP_SW_POS[0] - ox),
      "G21", "G90", "G17", "G94", "T1 M6", f"S{S} M3", "G4 P2", f"G0 Z{SAFE+5:.2f}"]
for name, pos, a0, a1, radii in ops:
    L += [f";@MKR|TOOLPATH_START|name=Drazka {name}", f"; --- {name}: oblouk {a0:.1f} az {a1:.1f} st. (CW od +Y) ---"]
    cx, cy = pos[0] - ox, pos[1] - oy
    x, y = P(radii[0], a0, pos)
    L += [f"G0 X{x:.3f} Y{y:.3f}", f"G0 Z{SAFE:.2f}", f"G1 Z0.200 F{FZ}"]
    z = 0.0; n = 0
    depths = []
    while z < g["depth"] - 1e-6:
        z = min(g["depth"], z + STEPDN); depths.append(z)
    for z in depths:                        # cela drazka do plne hloubky, pak dalsi
        # na zacatku (a0) do hloubky na vnitrnim polomeru
        x, y = P(radii[0], a0, pos)
        L += [f"G1 X{x:.3f} Y{y:.3f} F{F}", f"G1 Z{-z:.3f} F{FZ}"]
        # vnitrni oblouk a0 -> a1 (po smeru hodin = G2)
        x1, y1 = P(radii[0], a1, pos)
        L += [f"G2 X{x1:.3f} Y{y1:.3f} I{cx - x:.3f} J{cy - y:.3f} F{F}"]
        # prejezd na vnejsi polomer a zpet a1 -> a0 (G3)
        x2, y2 = P(radii[1], a1, pos)
        L += [f"G1 X{x2:.3f} Y{y2:.3f}"]
        x3, y3 = P(radii[1], a0, pos)
        L += [f"G3 X{x3:.3f} Y{y3:.3f} I{cx - x2:.3f} J{cy - y2:.3f}"]
    L += [f"G0 Z{SAFE:.2f}"]
L += [f"G0 Z{SAFE+10:.2f}", "M9", "M05", "G28", "M02"]
open('/home/claude/vystup/drazky_dorazy_Z1.nc', 'w').write("\n".join(L) + "\n")
print("\n".join(L[:40])); print('...', len(L), 'radku')
