#!/usr/bin/env python3
"""
Parametricka krabicka rucniho MPG ovladace (Makera Z1 Pro, emulace WHB04B).

Dily:
  - teleso        : horni panel + steny, tiskne se panelem na podlozku
  - dno           : spodni deska se zdirkami pro sroubky M3 a drzakem Pro Micro
  - vlozka_popisky: jedna vymenna vlozka s popisky obou volicu (OFF/X/Y/Z/A a 0.001/0.01/0.1/1)
  - displej OLED 0,96" (M508): okenko a ramecek v panelu nad volici
  - knoflik       : knoflik na RS16 (D hridel 6 mm) s ryskou a stavecim sroubem M3

Pravidla tolerance (podle zadani):
  - otvory = jmenovity rozmer + TOL (0,3 mm)
  - vlozka = kapsa zmensena o INSERT_GAP celkem (0,5 mm, tj. 0,25 na stranu)

Vyzaduje: pip install manifold3d numpy fonttools
Spusteni: python mpg_box.py  -> vystupy do slozky ./vystup
"""
import math, os, zipfile, struct
import numpy as np
import manifold3d as m3
from manifold3d import Manifold as M, CrossSection as CS
from fontTools.ttLib import TTFont
from fontTools.pens.basePen import BasePen

m3.set_circular_segments(96)

# --------------------------------------------------------------- PARAMETRY ---
TOL = 0.3            # vule otvoru
INSERT_GAP = 0.5     # vlozka mensi nez kapsa (celkem)

# vnejsi rozmery krabicky
SW_DEPTH = 9.5 + 5.0                # prepinac RS16 pod panelem: telo 9,5 + vyvody 5 (zmereno)
WIRE_SPACE = 5.0                    # pod prepinaci misto na vodice
W, L, H = 85.0, 133.5, 3.0 + SW_DEPTH + WIRE_SPACE + 3.0   # X sirka, Y delka (bez ucha), Z vyska vc. dna (panel + dutina + dno) = 25,5

# zaobleni celni hrany panelu bez podper: oblouk R jen do 45 st., pak sraz 45 st. k podlozce
FACE_R = 5.0
FACE_CHAMFER = 1.5                  # vyska srazu 45 st. u celni plochy
R_CORNER = 8.0                      # rohy u kolecka
R_CORNER_TOP = 18.0                 # zaobleni ramen u ucha
WALL = 2.4
PANEL_T = 3.0                       # tloustka horniho panelu
BOTTOM_T = 3.0                      # tloustka dna

# MPG kolecko 60 mm - OVERIT POSUVKOU! (zakladni hodnoty z bezne vyrobni rady)
MPG_POS = (0.0, -L / 2 + 36.0)
MPG_BODY_D = 42.0                   # zadni cast kolem svorek (zmereno 42) -> otvor = +TOL
MPG_PCD = 53.0                      # roztec 3 svorniku M3 (odhad z fotky ~53, nezmereno)
MPG_PCD_SLOT = (49.0, 57.0)         # otvory pro svorniky jako radialni draZky -> roztec nemusi byt presna
MPG_SCREW_D = 3.0                   # M3 -> 3,3
MPG_SCREW_ANGLE0 = 90.0             # natoceni prvniho sroubu (stupne)

# RS26 otocne prepinace
RS26_THREAD_D = 8.8                 # RS16 L333F: montazni otvor 8,8 -> 9,1
RS26_BODY_D = 16.5                  # telo RS16 O16 (+vule), hloubka 9,5
SW_Y = MPG_POS[1] + 54.0                                     # voliče vedle sebe, nad nimi displej
AXIS_SW_POS = (-18.2, SW_Y)                                  # osy vlevo
STEP_SW_POS = (20.2, SW_Y)                                   # kroky vpravo
RS16_DETENT = 45.0                  # RS16 1x8: 8 poloh po 45 st., vnitrni doraz mezi 8 a 1
RS16_TAB = dict(r=(6.75, 8.5), w=2.5, depth=2.3)  # vystupek na obvodu tela O16: 1 (radialne) x 2 x vyska 2 mm -> drazka zespodu, nad ni zbyva 0,7 mm
RS26_PIN = None                     # (stare RS26, nepouzito)

# popisky a kapsy pro vlozky
POCKET_R_IN, POCKET_R_OUT = 10.5, 25.0
POCKET_HALF_ANGLE = 82.0            # sektor +-82 st. od osy +Y
POCKET_DEPTH = 1.2
TEXT_DEPTH = 0.6                    # barevny text (vicebarevny tisk)
TEXT_H = 4.8                        # vyska pisma osy
TEXT_H_STEP = 4.0                   # vyska pisma kroku
TEXT_R = 17.0                       # polomer stredu popisku (osy)
TEXT_R_STEP = 16.6                  # polomer stredu popisku (kroky - delsi texty)
TICK_R = (11.3, 13.6)               # znacky poloh
TICK_W = 0.9
AXIS_LABELS = [("OFF", -90), ("X", -45), ("Y", 0), ("Z", 45), ("A", 90)]      # polohy 1-5 (po 45 st.)
STEP_LABELS = [(".001", -67.5), (".01", -22.5), (".1", 22.5), ("1", 67.5)]   # polohy 1-4, bez uvodni nuly
LABEL_UPRIGHT = False               # True = popisky vodorovne; False = po obvodu (tangencialne)
# ve Windows napr. r"C:\Windows\Fonts\arialnb.ttf" (Arial Narrow Bold) nebo stazeny DejaVuSansCondensed-Bold.ttf
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf"

# Pro Micro (USB-C verze)
PM_L, PM_W, PM_T = 33.0, 18.0, 1.6     # Pro Micro 33 x 18 (vule +0,3 v drzaku)
PM_Z = 3.0                          # mezera pod DPS (pajeni) nad dnem
PM_LIP = 1.2                        # presah sikmych zobacku nad DPS (45 st., bez podper)
USB_OPEN_W, USB_OPEN_H = 13.0, 8.0  # otvor pro konektor kabelu USB-C
USB_Z_ABOVE_PCB = 1.6               # stred konektoru nad horni stranou DPS

# OLED 0,96" 128x64 I2C (Hadex M508): modul 27 x 27 x 4,1 mm, sklo ~26,7 x 19,3, viditelna plocha ~23,7 x 12,9
OLED_POS = (0.0, L / 2 - 10.15)      # stred skla: ~4,3 mm od popisku i od hrany otvoru ucha (zkracena verze)
OLED_WALL_TO_EAR = 2.0               # min. stena mezi kapsou DPS a otvorem ucha (kontrola)
OLED_GLASS = (26.7, 19.3, 1.6)       # sklo: sirka, vyska, hloubka kapsy v panelu (zbyva 1,4 mm nad sklem)
OLED_GLASS_TOL = 0.4                 # vule kapsy skla (celkem)
OLED_WIN = (24.6, 16.0)              # okenko (pokryje viditelnou plochu i pri posunu skla), na lici sraz 45 st.
OLED_PCB = (27.3, 27.8)              # DPS modulu
OLED_PCB_TOL = (0.6, 1.0)            # vule rameckru DPS (v ose pinu vetsi - poloha skla na DPS se lisi kus od kusu)
OLED_PCB_SHIFT = 1.5                 # stred DPS je od stredu skla posunut o tolik smerem k pinum
OLED_PINS_DIR = -1                   # piny dolu k volicum (-Y), obraz se ve FW otoci o 180 st. (setFlipMode)
OLED_FRAME_WALL, OLED_FRAME_H = 1.2, 4.0   # ramecek pod panelem (DPS se jen vlozi a zajisti kapkou tavneho lepidla)
OLED_PIN_GAP = 14.0                  # mezera v ramecku pro 4 piny

# srouby dna
BOSS_D = 8.0                        # sloupek pro samorezny sroub / vlozku
BOSS_D_NUT = 10.4                   # sloupek pro matici v bocni kapse
# --- upevneni dna: 3 varianty ---
FASTENING = "samorezne"             # "samorezne" | "vlozky" (lisovane za tepla) | "matice" (zatistena pri pauze tisku)
INSERT_D, INSERT_L = 4.0, 6.0       # otvor pro zalisovaci matici M3 (napr. M3x5.7, vnejsi ~4.2)
NUT_S, NUT_T = 5.5, 2.4             # matice M3: otvor klice, vyska (+TOL)
NUT_Z = 3.0                         # material mezi dnem a matici (tiskne se az PO vlozeni matice)
NUT_TOL = 0.5                       # vule matice (sirka i hloubka kapsy)
NUT_POCKET_H = 3.0                  # matice 2,4 + 0,5 -> zaokrouhleno na vrstvy 0,2; matice konci 0,6 mm pod dalsi vrstvou
SCREW_CLEAR = 3.3                   # pruchozi otvor M3
BOSS_INSET = 6.5                    # stred sloupku od vnejsi hrany
PILOT_D = 2.8                       # pro samorezny M3 (nebo 4.0 pro zalisovaci matici)
PILOT_DEPTH = 12.0
CSK_D = 6.6                         # zapusteni hlavy M3

# knoflik RS26
KNOB_D, KNOB_H = 20.0, 12.7           # RS16: hridel 14 mm nad montazni plochou -> 11 mm nad licem
SHAFT_D = 6.0                       # -> 6,3 + stavěcí sroub M3
SHAFT_DEPTH = 10.7                    # od spodu knofliku vc. vybrani -> knoflik dosedne hridelem 0,3 mm nad licem
KNOB_NUT_RECESS = (15.0, 3.0)         # vybrani pro matici (vrcholy 12,15) + podlozku O14
STOP_GROOVE = dict(r=8.7, w=2.4, depth=1.2, over=3.5)   # drazka v lici omezujici chod (polomer osy, sirka, hloubka, presah za krajni polohu st.)
KNOB_PIN = dict(d=2.0, l=1.4)         # kolik na spodku knofliku pod ryskou, jede v drazce
STOP_MODE = "vlozka"                  # omezeni chodu: "vlozka" = dorazy na zvysene vlozce (bez frezovani), "drazka" = frezovana drazka + kolik
INSERT_RAISE = 1.2                    # vlozka vystupuje nad lic (celkova tloustka = hloubka kapsy + tohle)
INSERT_STOPS = dict(w=2.0, r_in=8.9, margin=4.5)   # dorazy na vnitrnim okraji vlozky: sirka, vnitrni polomer, presah za krajni polohu (st.)
KNOB_LUG = dict(r_neck=8.6, w=2.0)    # spodni osazeni knofliku: krk O17,2 s vystupkem (plny O20) pod ryskou
GRUB_PILOT = 2.6

# ucho na zaveseni (horni konec, +Y), lezi v rovine panelu -> tiskne se na podlozce
# ucho na zaveseni: plne pokracovani krabicky na hornim konci (+Y) pres celou sirku a vysku,
# skrz prochazi otvor ve tvaru pulkruhu obloukem nahoru -> hacek vzdy sjede doprostred
# (svisly pri tisku -> bez podper)
EAR_RIM = 17.0                      # material kolem otvoru (vede jim kanal kabelu)
EAR_HOLE_R = 23.0                   # polomer pulkruhoveho otvoru (+TOL/2)
EAR_HOLE_CHAMFER = 1.5              # sraz 45 st. hrany otvoru na celni strane
EAR_LIFT_Y0 = 0.0                   # dno konci v L/2 + tato hodnota, dal je ucho soucasti telesa
# zaobleni spicky ucha pri pohledu z boku: (T, R) = hloubka od plochy, polomer oblouku.
# Profil: u plochy sraz 45 st., pak oblouk R az do svisle steny -> nikde previs > 45 st.
EAR_FRONT_ROUND = (min(27.0, H - 3.0 - 4.5), 26.0)   # z predni strany; sklon u plochy < 45 st. (bez podper), nizsi teleso
EAR_BACK_ROUND = None               # zada jsou rovna (dno pres cele ucho)
EAR_MIN_RIM = 4.0                   # minimalni material nad otvorem v kazde hloubce (kontrola)
EAR_HOLE_FLAT = 5.0                 # rovna strana otvoru: vzdalenost od hrany L/2
EAR_HOLE_FILLET = 2.0               # zaobleni rohu u rovne strany
# Pro Micro lezi napric, konektor USB-C miri do bocni steny (+X)
# kapsa pro zastrcku uvnitr ucha + drazka jen na prumer kabelu, obe otevrene ke dnu (dno je zavira)
PLUG_L = 22.0                       # pevna cast zastrcky USB-C (kontrola mista v dutine)
USB_CABLE_D = 4.0                   # prumer kabliku -> kanal 4,5 (pridavek 0,5)
CABLE_TOL = 0.5
CABLE_ARC_R = 31.0                  # kanal obchazi otvor ucha po oblouku (soustredne)
CABLE_EXIT_ANGLE = 35.0             # vystup kanalu: uhel od osy +Y (vpravo nahore), kolmo na obrys
PM_CONN_X, PM_Y = 7.0, L / 2 - 15.5         # (stara poloha, nepouzito)
PM_UNDER_MPG = True                         # Pro Micro na dne pod koleckem, konektor nahoru (k uchu)
# srouby dna do plneho ucha (dno je pres cele ucho)
EAR_SCREWS = [(-28.0, 5.0), (0.0, None), (36.5, -2.5)]   # (x, y od L/2); None = uprostred nad otvorem; posledni = strana s kablikem

OUT = "vystup"

# ------------------------------------------------------------ POMOCNIKY 2D ---
def rrect(w, l, r):
    return CS.square((w - 2 * r, l - 2 * r), center=True).offset(r, m3.JoinType.Round)

def circle(d):
    return CS.circle(d / 2)

def sector(r_in, r_out, half_angle, n=120):
    """Mezikruzi-vysec okolo osy +Y (uhel 0 = nahoru, kladne = po smeru hodin)."""
    pts = []
    for i in range(n + 1):
        a = math.radians(-half_angle + 2 * half_angle * i / n)
        pts.append((r_out * math.sin(a), r_out * math.cos(a)))
    for i in range(n, -1, -1):
        a = math.radians(-half_angle + 2 * half_angle * i / n)
        pts.append((r_in * math.sin(a), r_in * math.cos(a)))
    return CS([pts[::-1]]) if signed_area(pts) < 0 else CS([pts])

def signed_area(p):
    a = 0.0
    for i in range(len(p)):
        x1, y1 = p[i]; x2, y2 = p[(i + 1) % len(p)]
        a += x1 * y2 - x2 * y1
    return a / 2

def polar(r, deg):
    a = math.radians(deg)
    return (r * math.sin(a), r * math.cos(a))

# ------------------------------------------------------------------ TEXT ----
class FlatPen(BasePen):
    def __init__(self, gs):
        super().__init__(gs); self.contours = []; self.cur = []
    def _moveTo(self, p): self.cur = [p]
    def _lineTo(self, p): self.cur.append(p)
    def _curveToOne(self, p1, p2, p3):
        p0 = self.cur[-1]
        for i in range(1, 9):
            t = i / 8
            x = (1-t)**3*p0[0] + 3*(1-t)**2*t*p1[0] + 3*(1-t)*t**2*p2[0] + t**3*p3[0]
            y = (1-t)**3*p0[1] + 3*(1-t)**2*t*p1[1] + 3*(1-t)*t**2*p2[1] + t**3*p3[1]
            self.cur.append((x, y))
    def _qCurveToOne(self, p1, p2):
        p0 = self.cur[-1]
        for i in range(1, 7):
            t = i / 6
            x = (1-t)**2*p0[0] + 2*(1-t)*t*p1[0] + t**2*p2[0]
            y = (1-t)**2*p0[1] + 2*(1-t)*t*p1[1] + t**2*p2[1]
            self.cur.append((x, y))
    def _closePath(self):
        if len(self.cur) > 2: self.contours.append(self.cur)
        self.cur = []
    _endPath = _closePath

_font = TTFont(FONT)
_gs = _font.getGlyphSet(); _cmap = _font.getBestCmap()
_upm = _font["head"].unitsPerEm
_cap = getattr(_font["OS/2"], "sCapHeight", 0) or 0.729 * _upm

# --- prorazene popisky ve vlozce (sablona) ---
STENCIL_BRIDGE = 0.8                # mustky drzici "ostruvky" (jen pro prorazenou vlozku)
STENCIL_BRIDGES = False             # vlozka ma dole 1 vrstvu -> ostruvky drzi, mustky netreba
STENCIL_MIN_STROKE = 1.0            # vlastni "1": tloustka cary (aby nezanikla pri trysce 0,4)
STENCIL_DOT = 1.4                   # vlastni tecka: prumer (jako u puvodni tenke vlozky, ktera se povedla)
INSERT_FACE_T = 0.8                 # tloustka prorazene vlozky pri pouziti s bilym podkladem
UNDERLAY_T = POCKET_DEPTH - INSERT_FACE_T   # bily podklad pod vlozku (0,4 mm) -> dohromady hloubka kapsy

def _signed_area(pts):
    return 0.5 * sum(x0 * y1 - x1 * y0 for (x0, y0), (x1, y1) in zip(pts, pts[1:] + pts[:1]))

ONE_STYLE = "B"                     # vlastni jednicka: A = praporek 25 st. + patka, B = bez patky, C = vodorovny praporek + patka
ONE_FLAG_T = 0.85                   # tloustka praporku
ONE_CAP_R = 0.0                     # o kolik vrchni vystupek presahuje drik doprava
ONE_FLAG_EXTRA = 0.4                # praporek delsi doleva nez u puvodni jednicky
def _glyph_one(cap_h, gx0, gx1, style=None):
    """Jednicka pro tisk tryskou 0,4 / vrstva 0,16 ve stejne sirce jako puvodni (gx0..gx1):
    silny drik, praporek pod mirnym uhlem (sirsi klin mezi praporkem a drikem -> vrch se neslije)."""
    style = style or ONE_STYLE
    sw = max(STENCIL_MIN_STROKE, 0.2 * cap_h)
    h = cap_h
    sr = gx1 - 0.25 if style != "B" else gx1 - max(ONE_CAP_R, 0.1)
    sl = sr - sw
    stem = CS.square((sw, h)).translate((sl, 0))
    fl = sl - gx0 + ONE_FLAG_EXTRA
    drop = 0.0 if style == "C" else fl * math.tan(math.radians(25))
    ft = ONE_FLAG_T
    fx = sl - fl
    flag = CS([[(sl + 0.01, h), (fx, h - drop), (fx, h - ft - drop), (sl + 0.01, h - ft)]])   # CCW
    g = stem + flag
    if ONE_CAP_R > 0:                               # vrchni vystupek protazeny kousek doprava za drik
        g = g + CS.square((sw + ONE_CAP_R, ft)).translate((sl, h - ft))
    if style in ("A", "C"):
        g = g + CS.square((gx1 - gx0, 0.8)).translate((gx0, 0))
    return g

def text2d(s, cap_h, stencil=False):
    """Text jako CrossSection, vycentrovany na (0,0), vyska velkych pismen = cap_h.
    stencil=True: verze pro prorazenou vlozku - vlastni "1" a vetsi tecka, mustky pres ostruvky.
    Rozmisteni znaku (posuv) je stejne jako u normalniho textu."""
    k = cap_h / _cap
    x = 0.0; parts = []; allc = []
    for ch in s:
        g = _cmap[ord(ch)]
        pen = FlatPen(_gs); _gs[g].draw(pen)
        cont = [[(x + px * k, py * k) for px, py in c][::-1] for c in pen.contours]   # TrueType: vnejsi obrys CW -> otocit
        allc += cont
        if stencil:
            gcs = CS(cont)
            if ch == "1":
                bx0, _, bx1, _ = gcs.bounds()
                gcs = _glyph_one(cap_h, bx0 + 0.12, bx1 - 0.12)    # o chlup uzsi nez puvodni "1" (ostre rohy) -> vejde se do kapsy
            elif ch == ".":
                bx0, by0, bx1, by1 = gcs.bounds()
                d = max(STENCIL_DOT, bx1 - bx0)
                gcs = CS.circle(d / 2, 32).translate(((bx0 + bx1) / 2, d / 2))
            elif STENCIL_BRIDGES:
                for c in cont:                      # dira v glyfu = ostruvek -> svisly mustek pres stred
                    if _signed_area(c) < 0:
                        hx0 = min(p[0] for p in c); hx1 = max(p[0] for p in c)
                        gcs = gcs - CS.square((STENCIL_BRIDGE, 3 * cap_h)).translate(((hx0 + hx1) / 2 - STENCIL_BRIDGE / 2, -cap_h))
            parts.append(gcs)
        x += _gs[g].width * k
    ref = CS(allc)                                  # centrovani vzdy podle normalniho textu
    (x0, y0, x1, y1) = ref.bounds()
    cs = CS.batch_boolean(parts, m3.OpType.Add) if stencil else ref
    return cs.translate((-(x0 + x1) / 2, -cap_h / 2))

LABEL_CLEAR = 1.2                   # vodorovne popisky: nejblizsi bod textu tolik za koncem znacek
def upright_radius(t2, ang):
    """Polomer stredu vodorovneho popisku tak, aby jeho nejblizsi roh byl LABEL_CLEAR za znackami
    -> kratke i dlouhe popisky lezi stejne tesne kolem knofliku."""
    x0, y0, x1, y1 = t2.bounds()
    target = TICK_R[1] + LABEL_CLEAR
    lo, hi = 0.0, 60.0
    for _ in range(40):
        m = (lo + hi) / 2
        cx, cy = polar(m, ang)
        dx = max(x0 + cx, 0, -(x1 + cx)); dy = max(y0 + cy, 0, -(y1 + cy))
        if math.hypot(dx, dy) < target: lo = m
        else: hi = m
    return hi

INSERT_MIN_WALL = 0.9               # vlozka: min. stena mezi pismenem a okrajem (2 perimetry)
INSERT_TICK_GAP_MIN = 0.5           # vlozka: min. mezera puvodni znacka - pismeno (pismeno se smi posunout dovnitr jen do ni)
INSERT_SHIFT = {".01": 2.5, ".1": 2.0}   # rucni pootoceni popisku doprava (st.) -> vic mista za .001
_NUDGES = {}                        # (text, uhel) -> (posun dovnitr mm, pootoceni st.) pro vlozku

def label_art(labels, cap_h, text_r=None, stencil=False, nudges=None):
    """Popisky + znacky poloh okolo stredu prepinace (lokalni souradnice).
    stencil=True: verze pro vlozku (tiskove upravene znaky, popisky posunute od okraje)."""
    art = CS()
    nudges = _NUDGES if (stencil and nudges is None) else (nudges or {})
    for lab in labels:
        txt, ang = lab[0], lab[1]
        dr = lab[2] if len(lab) > 2 else 0.0          # volitelne odsazeni polomeru (stridani dvou rad)
        nd = nudges.get((txt, ang), (0.0, 0.0))
        ndr, nda = nd[0], nd[1]
        spin = nd[2] if len(nd) > 2 else 0.0          # natoceni textu kolem jeho stredu (+ = po smeru hodin)
        if LABEL_UPRIGHT:
            t2 = text2d(txt, cap_h)
            rr = upright_radius(t2, ang) + dr
        else:
            t2 = text2d(txt, cap_h, stencil).rotate(-(ang + nda + spin))
            rr = (text_r or TEXT_R) + dr - ndr
        art = art + t2.translate(polar(rr, ang + nda))
        t0 = TICK_R[0]                               # znacky vzdy puvodni
        t_end = TICK_R[1] if LABEL_UPRIGHT else max(TICK_R[1], rr + ndr - cap_h / 2 - 1.2)
        tick = CS.square((TICK_W, t_end - t0), center=True)
        tick = tick.translate((0, (t0 + t_end) / 2)).rotate(-ang)
        art = art + tick
    return art

def compute_insert_nudges():
    """Pro kazdy popisek najdi nejmensi posun dovnitr (a pripadne pootoceni), aby ve vlozce
    zustala k okraji stena aspon INSERT_MIN_WALL. Obrys vlozky (= kapsa v tele) se nemeni."""
    _NUDGES.clear()
    sh = insert_shape2d()
    inner = sh.offset(-INSERT_MIN_WALL, m3.JoinType.Round)
    for p, labels, h, r in SWITCHES():
        for lab in labels:
            best = None
            extra = INSERT_SHIFT.get(lab[0], 0.0)
            kmax = int(round(max(0.0, (r - h / 2) - (TICK_R[1] + INSERT_TICK_GAP_MIN)) / 0.1))
            for nda in [extra + d for d in (0.0, -1.5, 1.5, -3.0, 3.0, -4.5, 4.5)]:
                for k in range(0, kmax + 1):
                    ndr = 0.1 * k
                    t = text2d(lab[0], h, True).rotate(-(lab[1] + nda)).translate(polar(r - ndr, lab[1] + nda)).translate(p)
                    if (t - inner).area() < 1e-4:
                        cost = ndr + abs(nda - extra) * 0.3
                        if best is None or cost < best[0]:
                            best = (cost, ndr, nda)
                        break
            _NUDGES[(lab[0], lab[1])] = best[1:] if best else (0.1 * kmax, extra)
        # sousedni popisky od sebe aspon INSERT_MIN_WALL: pripadne pootocit ten dalsi o kousek dal
        for a_lab, b_lab in zip(labels, labels[1:]):
            def shp(l):
                ndr, nda = _NUDGES[(l[0], l[1])]
                return text2d(l[0], h, True).rotate(-(l[1] + nda)).translate(polar(r - ndr, l[1] + nda)).translate(p)
            for _ in range(6):
                if (shp(a_lab).offset(INSERT_MIN_WALL, m3.JoinType.Round) ^ shp(b_lab)).area() < 1e-4:
                    break
                ndr, nda = _NUDGES[(b_lab[0], b_lab[1])]
                _NUDGES[(b_lab[0], b_lab[1])] = (ndr, nda + 0.5)
    return dict(_NUDGES)

# ---------------------------------------------------------------- DILY ------
# Souradnice "sestava": z=0 spodek dna, z=H vrch panelu.
body_h = H - BOTTOM_T
def rrect2(w, l, r_bot, r_top):
    pts = []
    for (sx, sy, rr) in ((-1, -1, r_bot), (1, -1, r_bot), (-1, 1, r_top), (1, 1, r_top)):
        pts.append(CS.circle(rr).translate((sx * (w / 2 - rr), sy * (l / 2 - rr))))
    return CS.batch_hull(pts)

box_outline = rrect2(W, L, R_CORNER, R_CORNER_TOP)
inner = box_outline.offset(-WALL, m3.JoinType.Round)
# vnejsi obrys vcetne ucha: obalka krabicky a pulkruhu soustredneho s otvorem (konvexni)
outline = CS.batch_hull([box_outline, circle(2 * (EAR_HOLE_R + EAR_RIM)).translate((0, L / 2 + EAR_HOLE_FLAT))])
def ear_slot2d():
    r = EAR_HOLE_R
    half = circle(2 * r) ^ CS.square((2 * r + 2, r + 1)).translate((-r - 1, 0))
    half = half.offset(-EAR_HOLE_FILLET, m3.JoinType.Round).offset(EAR_HOLE_FILLET, m3.JoinType.Round)
    return half.offset(TOL / 2, m3.JoinType.Round).translate((0, L / 2 + EAR_HOLE_FLAT))

def mpg_holes2d():
    h = circle(MPG_BODY_D + TOL)
    for i in range(3):
        ang = MPG_SCREW_ANGLE0 + 120 * i
        h = h + CS.batch_hull([circle(MPG_SCREW_D + TOL).translate(polar(MPG_PCD_SLOT[0] / 2, ang)),
                               circle(MPG_SCREW_D + TOL).translate(polar(MPG_PCD_SLOT[1] / 2, ang))])
    return h.translate(MPG_POS)

def rs26_hole2d(pos):
    h = circle(RS26_THREAD_D + TOL)
    if RS26_PIN:
        h = h + circle(3.0 + TOL).translate(polar(*RS26_PIN))
    return h.translate(pos)

def stop_groove2d(labels):
    """Obloukova drazka (lokalne) pro kolik knofliku: od prvni do posledni polohy + presah, kulate konce."""
    g = STOP_GROOVE
    a0 = labels[0][1] - g["over"]; a1 = labels[-1][1] + g["over"]
    n = max(8, int((a1 - a0) / 3))
    pts = [polar(g["r"], a0 + (a1 - a0) * i / n) for i in range(n + 1)]
    return CS.batch_boolean([CS.batch_hull([circle(g["w"]).translate(p), circle(g["w"]).translate(q)]) for p, q in zip(pts, pts[1:])], m3.OpType.Add)

def stop_groove3d(pos, labels):
    d = STOP_GROOVE["depth"]
    return stop_groove2d(labels).translate(pos).extrude(d + 0.01).translate((0, 0, H - d))

def rs16_tab_slot(pos, labels):
    """Slepa draZka zespodu panelu pro vystupek proti pootoceni: lezi mezi polohou 8 a 1,
    tj. o pul kroku pred prvnim popiskem."""
    ang = labels[0][1] - RS16_DETENT / 2
    r0, r1 = RS16_TAB["r"]
    sl = CS.square((RS16_TAB["w"], r1 - r0)).translate((-RS16_TAB["w"] / 2, r0)).rotate(-ang)
    return sl.translate(pos).extrude(RS16_TAB["depth"] + 0.01).translate((0, 0, H - PANEL_T - 0.01))

def _boss(sx, sy):
    if sy > 0:   # horni sloupky na bocnich stenach nize (misto pro Pro Micro a zastrcku)
        return (sx * (W / 2 - WALL - BOSS_D / 2 + 0.6), L / 2 - 30.0)
    rc = R_CORNER
    d = (rc - WALL - BOSS_D / 2 + 0.6) / math.sqrt(2)      # sloupek v rohu, lehce zapusteny do steny
    return (sx * (W / 2 - rc + d), sy * (L / 2 - rc + d))
boss_pts = [_boss(sx, sy) for sx in (-1, 1) for sy in (-1, 1)]

def ear_cutter(z_bot, z_top, ch_bot, ch_top):
    """Otvor ucha se srazy 45 st. na koncich (bez podper)."""
    h = ear_slot2d()
    parts = [h.extrude(z_top - z_bot + 2).translate((0, 0, z_bot - 1))]
    if ch_top:
        parts.append(M.batch_hull([h.extrude(0.01).translate((0, 0, z_top - ch_top)),
                                   h.offset(ch_top + 1).extrude(0.01).translate((0, 0, z_top + 1))]))
    if ch_bot:
        parts.append(M.batch_hull([h.extrude(0.01).translate((0, 0, z_bot + ch_bot)),
                                   h.offset(ch_bot + 1).extrude(0.01).translate((0, 0, z_bot - 1))]))
    return M.batch_boolean(parts, m3.OpType.Add)

BOT_R = 5.0                         # zaobleni hrany dno/boky (oblouk, u podlozky prechod do 45 st. -> bez podper)
def bottom_inset(z):
    """Odsazeni obrysu ve vysce z nad spodni plochou dna."""
    import math as _m
    if z >= BOT_R:
        return 0.0
    z45 = BOT_R * (1 - 1 / _m.sqrt(2))
    if z <= z45:
        return z45 + (z45 - z)
    u = BOT_R - z
    return BOT_R - _m.sqrt(max(0.0, BOT_R * BOT_R - u * u))

def face_inset(t):
    """Odsazeni obrysu v hloubce t pod celni plochou (oblouk do 45 st. + sraz 45 st.)."""
    import math as _m
    a45 = FACE_R * (1 - _m.cos(_m.radians(45)))
    cz = FACE_CHAMFER + FACE_R * _m.sin(_m.radians(45))
    if t <= FACE_CHAMFER:
        return a45 + (FACE_CHAMFER - t)
    if t >= cz:
        return 0.0
    s = (cz - t) / FACE_R
    return FACE_R * (1 - _m.sqrt(max(0.0, 1 - s * s)))

EAR_C = (0.0, L / 2 + EAR_HOLE_FLAT)
EAR_OUTER_R = EAR_HOLE_R + EAR_RIM

def slice_outline(z, ear_variant):
    """Obrys tělesa ve výšce z: spicka ucha se zmensuje soustredne (zaobleni sleduje pulkruh),
    cela plocha ma zaobleni FACE_R."""
    d = 0.0
    T, R = EAR_FRONT_ROUND
    d += ear_round_inset(H - z, T, R)
    if ear_variant == "both" and EAR_BACK_ROUND:
        T, R = EAR_BACK_ROUND
        d += ear_round_inset(z, T, R)
    f = max(face_inset(H - z), bottom_inset(z))
    box = box_outline.offset(-f, m3.JoinType.Round) if f > 0 else box_outline
    # na spicce ucha se zaobleni nescitaji (max) -> sklon nikde pres 45 st.
    return CS.batch_hull([box, circle(2 * (EAR_OUTER_R - max(d, f))).translate(EAR_C)])

def outer_solid(ear_variant="front"):
    """Plne vnejsi teleso (konvexni obrysy -> obalka vrstev), vcetne ucha az k podlozce."""
    zs = sorted(set([BOTTOM_T + round(i * 0.5, 3) for i in range(int((H - BOTTOM_T) / 0.5) + 1)] + [H - 0.001]))
    slices = [slice_outline(z, ear_variant).extrude(0.001).translate((0, 0, min(z, H - 0.001))) for z in zs if z <= H]
    return M.batch_hull(slices)

def ear_round_inset(t, T, R):
    """Odsazeni spicky ucha v hloubce t od plochy (45 st. u plochy, pak oblouk R do svisle)."""
    a = R / math.sqrt(2)
    t1 = T - a
    if t >= T:
        return 0.0
    if t >= t1:
        u = T - t
        return R - math.sqrt(max(0.0, R * R - u * u))
    return (R - a) + (t1 - t)

def ear_round_cutter(front=True, back=False):
    """Orez spicky ucha profilem v rovine YZ, protazeny pres celou sirku (osa X)."""
    y_tip = outline.bounds()[3]
    cut = None
    for side, spec in (("front", EAR_FRONT_ROUND if front else None), ("back", EAR_BACK_ROUND if back else None)):
        if not spec:
            continue
        T, R = spec
        ts = [T * i / 40 for i in range(41)]
        if side == "front":
            pts = [(y_tip - ear_round_inset(t, T, R), H - t) for t in ts]
            pts = [(pts[0][0], H + 1)] + pts + [(y_tip + 10, H - T), (y_tip + 10, H + 1)]
        else:
            pts = [(y_tip - ear_round_inset(t, T, R), t) for t in ts]
            pts = [(pts[0][0], -1)] + pts + [(y_tip + 10, T), (y_tip + 10, -1)]
        poly = CS([pts]) if signed_area(pts) > 0 else CS([pts[::-1]])
        m = poly.extrude(W + 4).transform([[0, 0, 1, -W / 2 - 2], [1, 0, 0, 0], [0, 1, 0, 0]])
        cut = m if cut is None else cut + m
    return cut

def ear_lift_cutter():
    """Odebrani materialu pod obloukem: valec v ose X, tecny k podlozce v y0."""
    y0 = L / 2 + EAR_LIFT_Y0
    R = EAR_LIFT_R
    yb = outline.bounds()
    box = M.cube((W + 4, yb[3] - y0 + 5, R + 1)).translate((-W / 2 - 2, y0, -1))
    cyl = M.cylinder(W + 6, R, circular_segments=256).rotate((0, 90, 0)).translate((-W / 2 - 3, y0, R))
    return box - cyl

def oled_cut():
    """Okenko displeje: sraz 45 st. od lice az ke sklu, nad nim vetsi kapsa pro sklo (bez podper)."""
    gx, gy, gd = OLED_GLASS
    wx, wy = OLED_WIN
    zt, zg = H, H - PANEL_T + gd            # lic, hranice okenko/kapsa skla
    ch = zt - zg                            # sraz pres celou zbyvajici tloustku
    win = M.batch_hull([CS.square((wx, wy), center=True).extrude(0.01).translate((0, 0, zg - 0.01)),
                        CS.square((wx + 2 * (ch + 0.5), wy + 2 * (ch + 0.5)), center=True).extrude(0.01).translate((0, 0, zt + 0.5))])
    glass = CS.square((gx + OLED_GLASS_TOL, gy + OLED_GLASS_TOL), center=True).extrude(gd + 0.5).translate((0, 0, H - PANEL_T - 0.5))
    return (win + glass).translate((OLED_POS[0], OLED_POS[1], 0))

def oled_frame():
    """Ramecek DPS pod panelem (svisle steny -> bez podper), mezera pro piny."""
    px, py = OLED_PCB[0] + OLED_PCB_TOL[0], OLED_PCB[1] + OLED_PCB_TOL[1]
    t = OLED_FRAME_WALL
    cy = OLED_POS[1] + OLED_PINS_DIR * OLED_PCB_SHIFT
    ring = CS.square((px + 2 * t, py + 2 * t), center=True) - CS.square((px, py), center=True)
    ring = ring - CS.square((OLED_PIN_GAP, 2 * t + 2), center=True).translate((0, OLED_PINS_DIR * (py / 2 + t / 2)))
    z1 = H - PANEL_T
    return ring.translate((OLED_POS[0], cy)).extrude(OLED_FRAME_H + 0.01).translate((0, 0, z1 - OLED_FRAME_H))

def oled_bay():
    """Kapsa pro DPS displeje v plne pricce pod uchem: svisle skrz az ke dnu (otevrena do dutiny,
    pri tisku licem dolu bez stropu -> bez podper). Dno ji zakryje."""
    px, py = OLED_PCB[0] + OLED_PCB_TOL[0], OLED_PCB[1] + OLED_PCB_TOL[1]
    cy = OLED_POS[1] + OLED_PINS_DIR * OLED_PCB_SHIFT
    return CS.square((px, py), center=True).translate((OLED_POS[0], cy)).extrude(H - PANEL_T - BOTTOM_T + 1).translate((0, 0, BOTTOM_T - 1))

def oled_pcb_box():
    """Obalka modulu vc. pinu a konektoru (kontrola kolizi)."""
    cy = OLED_POS[1] + OLED_PINS_DIR * OLED_PCB_SHIFT
    return CS.square(OLED_PCB, center=True).translate((OLED_POS[0], cy)).extrude(16).translate((0, 0, H - PANEL_T - 16))

def make_body(integrated_text=False, ear_variant="front"):
    z0 = BOTTOM_T
    outer = outer_solid(ear_variant)
    body = outer - inner.extrude(H - PANEL_T - z0 + 1).translate((0, 0, z0 - 1))
    # sloupky pro srouby dna
    bd = BOSS_D_NUT if FASTENING == "matice" else BOSS_D
    for p in boss_pts:
        boss = circle(bd).translate(p).extrude(body_h - PANEL_T + 0.5).translate((0, 0, z0))
        body = body + (boss ^ outer)
    for p in boss_pts:
        body = body - fastener_cut(p, FASTENING, slot_dir=(-p[0], -p[1]))
    # otvory v panelu
    holes = mpg_holes2d() + rs26_hole2d(AXIS_SW_POS) + rs26_hole2d(STEP_SW_POS)
    body = body - holes.extrude(PANEL_T + 2).translate((0, 0, H - PANEL_T - 1))
    body = body - rs16_tab_slot(AXIS_SW_POS, AXIS_LABELS) - rs16_tab_slot(STEP_SW_POS, STEP_LABELS)
    if STOP_MODE == "drazka":
        body = body - stop_groove3d(AXIS_SW_POS, AXIS_LABELS) - stop_groove3d(STEP_SW_POS, STEP_LABELS)
    body = body + oled_frame()
    body = body - oled_bay()
    body = body - oled_cut()
    body = body - usb_path()
    # ucho: otvor skrz celou vysku, sroubky dna do plneho materialu ucha
    body = body - ear_cutter(z0, H, 0, EAR_HOLE_CHAMFER)
    for p in ear_screw_pts():
        body = body - fastener_cut(p, ear_fastener(p))
    texts = []
    if integrated_text:
        for pos, labels, ch, tr in ((AXIS_SW_POS, AXIS_LABELS, TEXT_H, TEXT_R), (STEP_SW_POS, STEP_LABELS, TEXT_H_STEP, TEXT_R_STEP)):
            art = label_art(labels, ch, tr).translate(pos)
            cut = art.extrude(TEXT_DEPTH + 0.01).translate((0, 0, H - TEXT_DEPTH))
            body = body - cut
            texts.append(art.extrude(TEXT_DEPTH).translate((0, 0, H - TEXT_DEPTH)))
    else:
        body = body - pocket_all2d().extrude(POCKET_DEPTH + 0.01).translate((0, 0, H - POCKET_DEPTH))
    return body, texts

POCKET_MARGIN = 0.8                 # okraj kapsy kolem popisku
def pocket2d(labels, cap_h, text_r):
    """Kapsa vlozky: obalka popisku (+okraj) a znacek, bez otvoru knofliku -> nezabira sirku zbytecne."""
    art = label_art(labels, cap_h, text_r)
    angs = [lab[1] for lab in labels]
    ticks = sector(POCKET_R_IN, TICK_R[1] + 1.0, max(abs(min(angs)), abs(max(angs))) + 5)
    return CS.hull(art.offset(POCKET_MARGIN, m3.JoinType.Round) + ticks) - circle(2 * POCKET_R_IN)

SWITCHES = lambda: ((AXIS_SW_POS, AXIS_LABELS, TEXT_H, TEXT_R), (STEP_SW_POS, STEP_LABELS, TEXT_H_STEP, TEXT_R_STEP))

def pocket_all2d():
    """Spolecna kapsa obou volicu (vedle sebe by mezi kapsami zbyla prilis tenka prepazka)."""
    pk = CS.batch_boolean([pocket2d(l, h, r).translate(p) for p, l, h, r in SWITCHES()], m3.OpType.Add)
    pk = pk.offset(2.0, m3.JoinType.Round).offset(-2.0, m3.JoinType.Round)     # spojit mezeru
    for p, *_ in SWITCHES():
        pk = pk - circle(2 * POCKET_R_IN).translate(p)
    return pk

# rucne doladene posuny popisku ve vlozce: (posun dovnitr mm, pootoceni po oblouku st., [natoceni kolem stredu st.]); + = po smeru hodin
INSERT_NUDGES_MANUAL = {
    ("OFF", -90): (0.5, 1.5), ("X", -45): (0.4, 0.0), ("Y", 0): (0.4, 0.0), ("Z", 45): (0.4, 0.0), ("A", 90): (0.1, -1.5),
    (".001", -67.5): (0.5, 1.5, 6.0), (".01", -22.5): (0.5, 2.5, 6.0),     # 3. cislo: natoceni textu kolem stredu
    (".1", 22.5): (0.5, 2.0), ("1", 67.5): (0.5, -3.0),
}

def labels_all2d(stencil=False):
    if stencil and not _NUDGES:
        _NUDGES.update(INSERT_NUDGES_MANUAL)
    return CS.batch_boolean([label_art(l, h, r, stencil=stencil).translate(p) for p, l, h, r in SWITCHES()], m3.OpType.Add)

def insert_shape2d():
    shape = pocket_all2d().offset(-INSERT_GAP / 2, m3.JoinType.Round)
    for p, *_ in SWITCHES():
        shape = shape - circle(2 * POCKET_R_IN + INSERT_GAP).translate(p)   # vnitrni okraj taky +0,25
    return shape

def make_insert():
    """Jedna vlozka s popisky obou volicu, v tiskove orientaci: lic dole (z=0), text 0..TEXT_DEPTH."""
    shape = insert_shape2d().mirror((1, 0))                 # tiskne se licem dolu -> zrcadlit
    art = labels_all2d().mirror((1, 0))
    base = shape.extrude(POCKET_DEPTH)
    text = (art ^ shape).extrude(TEXT_DEPTH)
    base = base - art.extrude(TEXT_DEPTH + 0.01).translate((0, 0, -0.01))
    return base, text

def make_insert_stencil(thick):
    """Vlozka s PRORAZENYMI popisky (sablona) - tiskne se jednou barvou, licem dolu.
    Obrys je stejny jako kapsa v tele (ta zustava stejna)."""
    shape = insert_shape2d()
    art = labels_all2d(stencil=True) ^ shape.offset(-0.45, m3.JoinType.Round)   # min. stena k okraji
    return (shape - art).mirror((1, 0)).extrude(thick)

INSERT_BOTTOM_LAYER = 0.16          # vyska vrstvy (0,16)
INSERT_TEXT_DEPTH = 1.04            # hloubka popisku od lice (jako u tenke vlozky 1,2 - 0,16)

def insert_stops2d():
    """Dorazy na vnitrnim okraji vlozky (smer ke stredu prepinace), za prvni a posledni polohou."""
    st = INSERT_STOPS
    r_out = POCKET_R_IN + INSERT_GAP / 2 + 0.6           # zapusteni do vlozky
    half_lug = math.degrees(KNOB_LUG["w"] / 2 / ((KNOB_LUG["r_neck"] + KNOB_D / 2) / 2))
    half_tab = math.degrees(st["w"] / 2 / ((st["r_in"] + r_out) / 2))
    out = []
    band_r0 = KNOB_D / 2 + 0.3                           # spojovaci pas nad licem: vne drahy knofliku
    for pos, labels, *_ in SWITCHES():
        for a, a_lab in ((labels[0][1] - half_lug - st["margin"] - half_tab, labels[0][1] - 4.0),
                         (labels[-1][1] + half_lug + st["margin"] + half_tab, labels[-1][1] + 4.0)):
            tab = CS.square((st["w"], r_out - st["r_in"])).translate((-st["w"] / 2, st["r_in"])).rotate(-a)
            # pas od dorazu k vlozce (kapsa u krajni znacky) -> doraz drzi pevne i kde vlozka konci
            lo, hi = sorted((a, a_lab))
            band = sector(band_r0, band_r0 + 2.2, (hi - lo) / 2).rotate(-(lo + hi) / 2) if False else None
            pts_in = [polar(band_r0, lo + (hi - lo) * i / 12) for i in range(13)]
            pts_out = [polar(band_r0 + 2.2, hi - (hi - lo) * i / 12) for i in range(13)]
            band = CS([pts_in + pts_out]) if _signed_area(pts_in + pts_out) > 0 else CS([(pts_in + pts_out)[::-1]])
            out.append((tab + band).translate(pos))
    return CS.batch_boolean(out, m3.OpType.Add)

def make_insert_recess():
    """Vlozka zvysena o INSERT_RAISE nad lic, s dorazy chodu, v tiskove orientaci LICEM DOLU
    (dorazy lezi na podlozce -> bez podper). Popisky zahloubene az na posledni vrstvu (0,16 mm):
    posledni vrstvu lze tisknout bile (zmena barvy pred posledni vrstvou) nebo vlepit bile vyplne."""
    shape = insert_shape2d()
    t = POCKET_DEPTH + INSERT_RAISE
    art = labels_all2d(stencil=True) ^ shape
    base = shape.extrude(t)
    stops = insert_stops2d().extrude(INSERT_RAISE).translate((0, 0, POCKET_DEPTH))   # jen nad licem panelu
    cut = art.extrude(INSERT_TEXT_DEPTH + 0.01).translate((0, 0, t - INSERT_TEXT_DEPTH))   # puvodni hloubka popisku
    # tisk licem dolu: 1. a 2. vrstva u lice se roztlaci do zahloubeni -> tam zahloubeni o kousek rozsirit
    lay = INSERT_BOTTOM_LAYER
    keep = shape.offset(-0.3, m3.JoinType.Round)            # k okraji vlozky nechat aspon 0,3 mm
    for i, e in enumerate(FACE_FOOT):
        wide = art.offset(e, m3.JoinType.Round) ^ keep
        cut = cut + wide.extrude(lay + 0.01).translate((0, 0, t - lay * (i + 1)))
    ins = base + stops - cut
    return ins                                                # orientace jako puvodni tenka vlozka (lic nahoru); tiskne se licem dolu

MMU_TEXT_DEPTH = 0.64               # MMU vlozka: hloubka barevneho textu (4 vrstvy po 0,16)

def make_insert_mmu():
    """Zvysena vlozka s dorazy pro tisk dvema barvami (MMU): cerne telo + bile popisky (bez vul),
    v tiskove orientaci LICEM DOLU (dorazy i popisky na podlozce)."""
    shape = insert_shape2d()
    t = POCKET_DEPTH + INSERT_RAISE
    art = labels_all2d(stencil=True) ^ shape
    body = shape.extrude(t) + insert_stops2d().extrude(INSERT_RAISE).translate((0, 0, POCKET_DEPTH))
    text = art.extrude(MMU_TEXT_DEPTH).translate((0, 0, t - MMU_TEXT_DEPTH))
    body = body - text
    flip = lambda m: m.rotate((0, 180, 0)).translate((0, 0, t))
    return flip(body), flip(text)

INLAY_GAP = 0.17                    # vule vyplni na stranu (PETG): 0,12 bylo tesne -> o 0,1 mm mensi
INLAY_FOOT = 0.0                    # zuzeni 1. vrstvy vyplni (0 = ne; tenke tahy by se rozpadly -> radeji kompenzace ve sliceru)
FACE_FOOT = ()                      # rozsireni zahloubeni u lice vypnuto (zmensovalo ostruvky A a 0) -> radeji kompenzace slonovy nohy ve sliceru
INLAY_T = 0.96                      # vyska vyplni = 6 vrstev po 0,16 (zahloubeni 1,04 -> 0,08 pod licem)

def make_label_inlays():
    """Vyplne (bile) do zahloubenych popisku vlozky: vsechna pismena, cislice, tecky i znacky,
    v presne poloze jako ve vlozce (lic nahoru) -> podle rozlozeni se snadno priradi."""
    art = labels_all2d(stencil=True) ^ insert_shape2d()
    return _inlay_extrude(art.offset(-INLAY_GAP, m3.JoinType.Round), INLAY_T)

def _inlay_extrude(cs, h):
    """Vypln: prvni vrstva (0,16) uzsi o INLAY_FOOT proti slonove noze, zbytek plny."""
    lay = INSERT_BOTTOM_LAYER
    if INLAY_FOOT <= 0:
        return cs.extrude(h)
    foot = cs.offset(-INLAY_FOOT, m3.JoinType.Round)
    return foot.extrude(lay + 0.01) + cs.extrude(h - lay).translate((0, 0, lay))

def make_knob_inlays(n=2):
    """Vyplne rysky knofliku: drazka na celni plose + V drazka po boku (lezi sirsi stranou dolu)."""
    w, dp = KNOB_POINTER["w"], KNOB_POINTER["depth"]
    prof = circle(KNOB_D)
    sd = KNOB_POINTER["side_depth"]
    vee = CS([[(0, KNOB_D / 2 - sd), (sd + 0.3, KNOB_D / 2 + 0.5), (-sd - 0.3, KNOB_D / 2 + 0.5)]])
    top = (CS.square((w, KNOB_D / 2 - 1.5 + 1)).translate((-w / 2, 1.5)) ^ (prof - vee)).offset(-INLAY_GAP, m3.JoinType.Round)
    top3 = _inlay_extrude(top, dp - 0.04).translate((0, -top.bounds()[1], 0))
    side = (vee ^ prof).offset(-INLAY_GAP, m3.JoinType.Round)            # prurez (x, y-r)
    sb = side.bounds()
    side = side.translate((0, -sb[3]))                                    # vnejsi (sirsi) strana na y=0
    side3 = side.mirror((0, 1)).extrude(KNOB_H - 0.1).rotate((90, 0, 0))  # prurez do (x,z), delka v ose y
    side3 = side3.translate((0, 0, -side3.bounding_box()[2]))
    parts = []
    for i in range(n):
        parts.append(top3.translate((i * 6.0, 0, 0)))
        parts.append(side3.translate((i * 6.0 + 3.0 + 0.5, KNOB_H - 0.1 + 2 + 10, 0)))
    return M.batch_boolean(parts, m3.OpType.Add)

def make_underlay():
    """Bily podklad pod prorazenou vlozku (stejny obrys)."""
    return insert_shape2d().mirror((1, 0)).extrude(UNDERLAY_T)

PM_POST = dict(t=1.6, arm=3.2, lip=1.0, pad=2.0)        # pevne rohove sloupky (predni konec, bez konektoru)
PM_TONGUE = dict(t=1.0, lip=0.7, gap=0.4)                # pruzne jazycky u konektoru (zacvaknuti)

def pm_holder():
    """Drzak Pro Micro v lokalnich souradnicich: konektor miri do +Y, zadni hrana DPS v y=0.
    Rohy predniho konce: pevne L-sloupky se zobackem (DPS se pod ne zasune sikmo).
    Rohy u konektoru: bocni doraz + samostatny pruzny jazycek se zobackem a nabehem -> DPS se zacvakne.
    Vsechny zobacky jsou nad kratkymi hranami (u rohu nejsou piny), spodek 45 st. -> bez podper."""
    rear_y = 0.0
    front_y = rear_y - PM_L
    pcb_z = BOTTOM_T + PM_Z
    t, arm, lip, pad = PM_POST["t"], PM_POST["arm"], PM_POST["lip"], PM_POST["pad"]
    tt, tlip, tgap = PM_TONGUE["t"], PM_TONGUE["lip"], PM_TONGUE["gap"]
    x_face = (PM_W + TOL) / 2
    z_lip = pcb_z + PM_T + TOL
    # opery pod stredem kratkych hran (piny jsou az 2,5 mm od konce)
    h = CS.square((10, 4), center=True).translate((0, rear_y - 2)).extrude(PM_Z).translate((0, 0, BOTTOM_T))
    h = h + CS.square((10, 4), center=True).translate((0, front_y + 2)).extrude(PM_Z).translate((0, 0, BOTTOM_T))

    def lip_x(profile, x0, length, y_face, sy):
        """Profil zobacku v rovine (u=dovnitr nad DPS zaporne, z) vytazeny po X od x0."""
        p3 = CS([profile]).extrude(length).rotate((90, 0, 90))
        if sy < 0:
            p3 = p3.mirror((0, 1, 0))
        return p3.translate((x0, y_face, 0))

    for sx in (-1, 1):
        xin0 = x_face - arm if sx > 0 else -x_face                        # zacatek ramena nad DPS (v X)
        xs_out = x_face if sx > 0 else -x_face - t                         # bocni rameno vedle DPS
        # --- predni roh: pevny L-sloupek ---
        ye = front_y - TOL / 2
        z_top = z_lip + lip
        end_arm = CS.square((arm + t, t)).translate((x_face - arm if sx > 0 else -x_face - t, ye - t))
        side_arm = CS.square((t, arm + t)).translate((xs_out, ye - t))
        post = (end_arm + side_arm).extrude(z_top - BOTTOM_T).translate((0, 0, BOTTOM_T))
        post = post + CS.square((pad, pad)).translate((x_face - pad if sx > 0 else -x_face, ye)).extrude(PM_Z).translate((0, 0, BOTTOM_T))
        post = post + lip_x([(0.0, z_lip), (0.0, z_top), (-lip, z_top)], xin0, arm, ye, -1)
        h = h + post
        # --- zadni roh (u konektoru): bocni doraz + pruzny jazycek ---
        ye = rear_y + TOL / 2
        z_top2 = z_lip + 2 * tlip
        side = CS.square((t, arm + t)).translate((xs_out, ye - arm)).extrude(z_lip - BOTTOM_T).translate((0, 0, BOTTOM_T))
        side = side + CS.square((pad, pad)).translate((x_face - pad if sx > 0 else -x_face, ye - pad)).extrude(PM_Z).translate((0, 0, BOTTOM_T))
        tongue_w = arm - tgap
        tx0 = x_face - arm if sx > 0 else -x_face + tgap
        tongue = CS.square((tongue_w, tt)).translate((tx0, ye)).extrude(z_top2 - BOTTOM_T).translate((0, 0, BOTTOM_T))
        tongue = tongue + lip_x([(0.0, z_lip), (0.0, z_top2), (-tlip, z_lip + tlip)], tx0, tongue_w, ye, 1)
        h = h + side + tongue
    return h

def pm_place(man):
    """Lokalni souradnice drzaku -> sestava (podelne vpravo, konektor k uchu)."""
    if PM_UNDER_MPG:
        return man.translate((MPG_POS[0], MPG_POS[1] + PM_L / 2, 0))      # stred desky pod stredem kolecka
    return man.rotate((0, 0, -90)).translate((PM_CONN_X, PM_Y, 0))

def fastener_cut(p, kind, slot_dir=None):
    """Otvor pro upevneni dna v bode p (od styku s dnem nahoru). Vse bez podper:
    otvory svisle, kapsa matice ma jen kratky most sirky NUT_S."""
    z0 = BOTTOM_T
    if kind == "samorezne":
        return circle(PILOT_D).translate(p).extrude(PILOT_DEPTH + 0.01).translate((0, 0, z0 - 0.01))
    if kind == "vlozky":
        c = circle(INSERT_D).translate(p).extrude(INSERT_L + 0.01).translate((0, 0, z0 - 0.01))
        c = c + M.cylinder(0.6, INSERT_D / 2 + 0.5, INSERT_D / 2).translate((p[0], p[1], z0 - 0.01))   # nabeh
        return c + circle(SCREW_CLEAR - 0.5).translate(p).extrude(INSERT_L + 3).translate((0, 0, z0))   # misto pro spicku
    # matice: uzavrena sestihranna kapsa; tisk se pozastavi, matice se vlozi a pokracuje se
    # (pri tisku panelem dolu se nosna vrstva nad matici tiskne az po vlozeni)
    c = circle(SCREW_CLEAR).translate(p).extrude(NUT_Z + NUT_POCKET_H + 6).translate((0, 0, z0 - 0.01))
    hexa = CS.circle((NUT_S + NUT_TOL) / math.sqrt(3), 6).translate(p)
    return c + hexa.extrude(NUT_POCKET_H).translate((0, 0, z0 + NUT_Z))

def nut_pause_height():
    """Vyska (tiskova orientace), po ktere se ma tisk pozastavit a vlozit matice."""
    return H - (BOTTOM_T + NUT_Z)

def ear_free_radius(p):
    """Volny polomer kolem bodu v plnem uchu (dutina, obrys, otvor ucha, kanal kabelu)."""
    pts = cable_path(); rr = (USB_CABLE_D + CABLE_TOL) / 2
    ch = CS()
    for a, b in zip(pts[:-1], pts[1:]):
        ch = ch + CS.batch_hull([CS.circle(rr).translate(a), CS.circle(rr).translate(b)])
    obs = (outline.offset(30) - outline) + inner + ear_slot2d() + ch
    c = CS.circle(0.01).translate(p); lo, hi = 0.0, 15.0
    for _ in range(22):
        m = (lo + hi) / 2
        if (c.offset(m) ^ obs).area() > 1e-6: hi = m
        else: lo = m
    return lo

def ear_fastener(p):
    """V uchu: pozadovany typ, pokud se vejde; jinak vlozka; jinak samorezny."""
    f = ear_free_radius(p)
    need = {"matice": (NUT_S + NUT_TOL) / math.sqrt(3) + 1.2, "vlozky": INSERT_D / 2 + 1.4, "samorezne": PILOT_D / 2 + 1.0}
    # ve verzi s maticemi bez vlozek: kde se matice nevejde, samorezny sroub
    for k in [FASTENING, "samorezne"]:
        if f >= need[k]:
            return k
    return "samorezne"

def ear_screw_pts():
    pts = []
    for x, y in EAR_SCREWS:
        if y is None:
            y = EAR_HOLE_FLAT + (EAR_HOLE_R + EAR_OUTER_R) / 2
        pts.append((x, L / 2 + y))
    return pts

def cable_path():
    """Osa kanalu kabliku: od konektoru Pro Micro (pod koleckem) rovne nahoru stredem mezi volici,
    pak sikmo doprava k uchu, po oblouku kolem otvoru a kolmo ven."""
    cx, cy = 0.0, L / 2 + EAR_HOLE_FLAT
    y_conn = MPG_POS[1] + PM_L / 2
    a0 = 95.0
    p_arc0 = (cx + CABLE_ARC_R * math.sin(math.radians(a0)), cy + CABLE_ARC_R * math.cos(math.radians(a0)))
    pts = [(0.0, y_conn + 2.0), (0.0, SW_Y + 12.0), (p_arc0[0] - 6.0, p_arc0[1] - 14.0)]
    for i in range(0, 25):
        a = a0 + (CABLE_EXIT_ANGLE - a0) * i / 24
        pts.append((cx + CABLE_ARC_R * math.sin(math.radians(a)), cy + CABLE_ARC_R * math.cos(math.radians(a))))
    out_r = EAR_OUTER_R + 6
    pts.append((cx + out_r * math.sin(math.radians(CABLE_EXIT_ANGLE)), cy + out_r * math.cos(math.radians(CABLE_EXIT_ANGLE))))
    return pts

def cable_channel():
    """Kulaty kanal pro kablik na styku telesa a zad: pulka v telese, pulka v zadech.
    Obe pulky jsou otevrene do styku -> pri tisku bez mostu i podper."""
    rr = (USB_CABLE_D + CABLE_TOL) / 2
    sph = [M.sphere(rr, 32).translate((x, y, BOTTOM_T)) for x, y in cable_path()]
    return M.batch_boolean([M.batch_hull([p, q]) for p, q in zip(sph[:-1], sph[1:])], m3.OpType.Add)

def usb_path():
    return cable_channel()

def make_bottom():
    zs = [round(i * 0.25, 3) for i in range(int(BOTTOM_T / 0.25) + 1)]
    plate = M.batch_hull([slice_outline(z, "front").extrude(0.001).translate((0, 0, min(z, BOTTOM_T - 0.001))) for z in zs])   # zaoblena hrana
    plate = plate - ear_cutter(0, BOTTOM_T, EAR_HOLE_CHAMFER, 0)
    plate = plate - cable_channel()
    for p in boss_pts + ear_screw_pts():
        plate = plate - circle(SCREW_CLEAR).translate(p).extrude(BOTTOM_T + 2).translate((0, 0, -1))
        plate = plate - M.cylinder(1.65, CSK_D / 2, SCREW_CLEAR / 2).translate((p[0], p[1], -0.01))
    return plate + pm_place(pm_holder())

KNOB_FLAT_DIR = -22.5               # D otvor (zjisteno z fotek: v poloze 1 ploska 22,5 st. proti smeru hodin od rysky): smer ploske hridele vuci rysce (st., po smeru hodin); None = kulaty otvor + stavěcí sroub
SHAFT_FLAT = 1.5                    # o kolik je hridel seriznuta (6 -> 4,5)
KNOB_BORE_TOL = 0.3                 # vule otvoru na hridel (celkem); drzeni zajisti zebra
KNOB_FLAT_GAP = 0.15                # vule u ploske D
KNOB_RIBS = dict(n=3, w=0.6, interf=0.1)   # lisovaci zebra v otvoru (zarez nozem, kdyby slo moc ztuha)
KNOB_POINTER = dict(w=1.4, depth=1.0, side_depth=1.0)   # ryska jako drazka (viditelna i pri tisku jednou barvou)

def make_knob():
    """Knoflik v tiskove orientaci: horni (pohledova) strana dole (z=0). Ryska smeruje do +Y."""
    prof = circle(KNOB_D)
    for i in range(18):
        if i in (0, 1, 17):                  # u rysky bez vroubku -> ryska je jasne poznat
            continue
        prof = prof - circle(2.2).translate(polar(KNOB_D / 2 + 0.4, i * 20))
    # svisla V drazka na boku v miste rysky
    sd = KNOB_POINTER["side_depth"]
    vee = CS([[(0, KNOB_D / 2 - sd), (sd + 0.3, KNOB_D / 2 + 0.5), (-sd - 0.3, KNOB_D / 2 + 0.5)]])
    prof = prof - vee
    knob = prof.extrude(KNOB_H)
    # otvor pro hridel
    bore = circle(SHAFT_D + KNOB_BORE_TOL)
    if KNOB_FLAT_DIR is not None:            # D: ploska ve vzdalenosti (D/2 - SHAFT_FLAT) od stredu (+ vule)
        fd = SHAFT_D / 2 - SHAFT_FLAT + KNOB_FLAT_GAP
        bore = bore - CS.square((SHAFT_D + 2, SHAFT_D)).translate((-(SHAFT_D + 2) / 2, fd)).rotate(KNOB_FLAT_DIR)   # tiskne se licem dolu -> zrcadlene
    if KNOB_FLAT_DIR is not None and KNOB_RIBS["n"]:
        # zebra na kulate casti otvoru (naproti plosce a do stran) - male presahy, ktere se pri nasunuti zamacknou
        r_tip = SHAFT_D / 2 - KNOB_RIBS["interf"]
        r_out = (SHAFT_D + KNOB_BORE_TOL) / 2 + 0.2
        for a in (180.0, 115.0, -115.0)[:KNOB_RIBS["n"]]:
            rib = CS.square((KNOB_RIBS["w"], r_out - r_tip)).translate((-KNOB_RIBS["w"] / 2, r_tip)).rotate(a)
            bore = bore - rib.rotate(KNOB_FLAT_DIR)
    knob = knob - bore.extrude(SHAFT_DEPTH + 0.01).translate((0, 0, KNOB_H - SHAFT_DEPTH))
    nd, nh = KNOB_NUT_RECESS                 # vybrani pro matici (v tisku nahore, otevrene -> bez podper)
    knob = knob - circle(nd).extrude(nh + 0.01).translate((0, 0, KNOB_H - nh))
    if KNOB_FLAT_DIR is None:
        # otvor pro stavěcí sroub ve tvaru kapky (strop 45 st. -> bez podper), proti rysce
        r = GRUB_PILOT / 2
        drop = CS.batch_hull([circle(GRUB_PILOT), CS.square((0.01, 0.01), center=True).translate((0, r * math.sqrt(2)))])
        grub = drop.extrude(KNOB_D).rotate((90, 0, 0)).translate((0, 0, KNOB_H - (SHAFT_DEPTH + KNOB_NUT_RECESS[1]) / 2))
        knob = knob - grub
    # ryska: drazka na celni plose od stredu k okraji (napoji se na V drazku na boku)
    w, dp = KNOB_POINTER["w"], KNOB_POINTER["depth"]
    line = CS.square((w, KNOB_D / 2 - 1.5 + 1)).translate((-w / 2, 1.5))
    pointer = line.extrude(dp) ^ prof.extrude(dp)
    knob = knob - line.extrude(dp + 0.01).translate((0, 0, -0.01))
    if STOP_MODE == "drazka":
        # kolik pro omezeni chodu: pod ryskou, na spodku knofliku (v tisku nahore -> bez podper)
        pin = circle(KNOB_PIN["d"]).translate((0, STOP_GROOVE["r"])).extrude(KNOB_PIN["l"]).translate((0, 0, KNOB_H))
        knob = knob + pin
    else:
        # spodni osazeni: vyska = kolik vlozka vystupuje nad lic (knoflik dosedne 0,3 mm nad licem);
        # zuzeny krk + vystupek pod ryskou, ktery narazi na dorazy vlozky
        nh_ = INSERT_RAISE - 0.3 + 0.3           # od spodku knofliku az nad horni plochu vlozky (+0,3)
        lug = CS.square((KNOB_LUG["w"], KNOB_D)).translate((-KNOB_LUG["w"] / 2, 0)) ^ circle(KNOB_D)
        neck = circle(2 * KNOB_LUG["r_neck"]) + lug
        ring = circle(KNOB_D + 2) - neck                                 # co se ze spodku odebere
        knob = knob - ring.extrude(nh_ + 0.01).translate((0, 0, KNOB_H - nh_))
    return knob, pointer

# ------------------------------------------------------------------ EXPORT ---
def mesh_arrays(man):
    mesh = man.to_mesh()
    v = np.asarray(mesh.vert_properties)[:, :3].astype(np.float64)
    t = np.asarray(mesh.tri_verts).astype(np.int64)
    return v, t

def write_stl(path, man):
    v, t = mesh_arrays(man)
    tri = v[t]
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    ln = np.linalg.norm(n, axis=1, keepdims=True); ln[ln == 0] = 1; n /= ln
    with open(path, "wb") as f:
        f.write(b"mpg_box".ljust(80, b"\0")); f.write(struct.pack("<I", len(t)))
        rec = np.zeros(len(t), dtype=[("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
        rec["n"] = n; rec["v"] = tri
        f.write(rec.tobytes())

def write_3mf(path, parts):
    """parts: [(nazev, Manifold, '#RRGGBB')] -> jeden objekt slozeny z dilu (multimaterial)."""
    mats = "".join(f'<base name="{n}" displaycolor="{c}FF"/>' for n, _, c in parts)
    objs, comps = [], []
    for i, (name, man, col) in enumerate(parts, start=2):
        v, t = mesh_arrays(man)
        vs = "".join(f'<vertex x="{a:.4f}" y="{b:.4f}" z="{c:.4f}"/>' for a, b, c in v)
        ts = "".join(f'<triangle v1="{a}" v2="{b}" v3="{c}"/>' for a, b, c in t)
        objs.append(f'<object id="{i}" name="{name}" type="model" pid="1" pindex="{i-2}"><mesh><vertices>{vs}</vertices><triangles>{ts}</triangles></mesh></object>')
        comps.append(f'<component objectid="{i}"/>')
    top = len(parts) + 2
    model = ('<?xml version="1.0" encoding="UTF-8"?>'
             '<model unit="millimeter" xml:lang="cs-CZ" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">'
             f'<resources><basematerials id="1">{mats}</basematerials>{"".join(objs)}'
             f'<object id="{top}" name="{os.path.splitext(os.path.basename(path))[0]}" type="model"><components>{"".join(comps)}</components></object>'
             f'</resources><build><item objectid="{top}"/></build></model>')
    ct = ('<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct); z.writestr("_rels/.rels", rels); z.writestr("3D/3dmodel.model", model)

def flip_for_print(man, top_z):
    """Otoci dil pohledovou (horni) plochou na podlozku."""
    return man.mirror((0, 0, 1)).translate((0, 0, top_z)).mirror((1, 0, 0))

def main():
    os.makedirs(OUT, exist_ok=True)
    bottom = make_bottom()
    ins = make_insert()
    knob, pointer = make_knob()
    for f in os.listdir(OUT):
        if f.startswith("teleso_"):
            os.remove(os.path.join(OUT, f))
    global FASTENING
    for fv, fname in (("samorezne", "samorezne"), ("vlozky", "lisovane_vlozky"), ("matice", "matice")):
        FASTENING = fv
        body, _ = make_body(False)
        body_mm, texts = make_body(True)
        body_p = flip_for_print(body, H)                 # tiskova orientace: panel na podlozce
        body_mm_p = flip_for_print(body_mm, H)
        texts_p = [flip_for_print(t, H) for t in texts]
        text_all = texts_p[0] + texts_p[1]
        write_stl(f"{OUT}/teleso_vymenne_popisky_{fname}.stl", body_p)
        write_3mf(f"{OUT}/teleso_popisky_multimaterial_{fname}.3mf", [("teleso", body_mm_p, "#2B2B2B"), ("popisky", text_all, "#F2F2F2")])
        print(fname, "ucho:", [ear_fastener(p) for p in ear_screw_pts()], "objem", round(body.volume() / 1000, 1), body.status())
        if fv == "matice":
            print("   PAUZA pro vlozeni matic: po vrstve konci na z =", nut_pause_height(), "mm (kapsy", round(nut_pause_height() - NUT_POCKET_H, 2), "-", nut_pause_height(), ")")
    write_stl(f"{OUT}/dno.stl", bottom)
    for f in os.listdir(OUT):
        if f.startswith("vlozka_"):
            os.remove(os.path.join(OUT, f))
    for nm, (b, t) in (("vlozka_popisky", ins),):
        write_3mf(f"{OUT}/{nm}.3mf", [(nm, b, "#2B2B2B"), ("text", t, "#F2F2F2")])
        write_stl(f"{OUT}/{nm}_zaklad.stl", b); write_stl(f"{OUT}/{nm}_text.stl", t)
    # zvysena vlozka pro MMU (2 barvy, licem dolu)
    mb, mt = make_insert_mmu()
    write_3mf(f"{OUT}/vlozka_zvysena_MMU.3mf", [("vlozka", mb, "#1E1E1E"), ("popisky", mt, "#F2F2F2")])
    write_stl(f"{OUT}/vlozka_zvysena_MMU_telo.stl", mb)
    write_stl(f"{OUT}/vlozka_zvysena_MMU_popisky.stl", mt)
    # vyplne (bile PETG) do popisku a do rysky knofliku
    write_stl(f"{OUT}/vypln_popisky_bila.stl", make_label_inlays())
    write_stl(f"{OUT}/vypln_ryska_knofliku_2ks_bila.stl", make_knob_inlays(2))
    # vlozka s popisky zahloubenymi az na 1 spodni vrstvu (lic nahoru, zmena barvy po 1. vrstve)
    ins_r = make_insert_recess()
    write_stl(f"{OUT}/vlozka_popisky_zahloubene.stl", ins_r)
    print("vlozka_popisky_zahloubene objem cm3:", round(ins_r.volume() / 1000, 2), "status:", ins_r.status(),
          "dilu:", len(ins_r.decompose()))
    write_3mf(f"{OUT}/knoflik.3mf", [("knoflik", knob, "#2B2B2B"), ("ryska", pointer, "#E03C31")])
    write_stl(f"{OUT}/knoflik.stl", knob)                 # ryska = drazka (jednou barvou), pripadne vyplnit barvou
    for nm, man in (("teleso", body), ("dno", bottom), ("vlozka_popisky", ins[0]), ("knoflik", knob)):
        print(nm, "objem cm3:", round(man.volume() / 1000, 1), "status:", man.status())

if __name__ == "__main__":
    main()
