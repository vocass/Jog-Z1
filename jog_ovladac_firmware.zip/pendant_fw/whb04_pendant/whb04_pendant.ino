/*
  Jog ovladac pro Makera Z1 Pro (Carvera Community Controller) a NestWorks C500
  -------------------------------------------------------------------------------
  Deska : Arduino Pro Micro 5 V / 16 MHz (ATmega32U4), v Arduino IDE jako "Arduino Leonardo"
  USB   : VID:PID musi byt 10CE:EB93 (nastavi boards.local.txt), jinak ho Controller nenajde

  Rezim Z1 (prepinac REZIM rozepnuty):
    Ovladac se tvari jako pendant XHC WHB04B. Controller posila polohy os, ty se zobrazuji na OLED.
  Rezim C500 (prepinac REZIM sepnuty):
    Pendant hlasi osu OFF (Controller nic nepohne) a jog posila na virtualni seriovy port
    presne ve tvaru, jaky pouziva Nest Studio:  $J=G21G91X<d>Y0Z0F<f>  (A: X0Y0A<d>), stop = 0x85.
    Most na PC (gRPC ke stroji) prikazy preposle stroji a zpet posila stavova hlaseni stroje
    (<Idle|MPos:..|WPos:..|MS:....|..>). Z nich ovladac zobrazuje polohu (WPos) a podle MS
    blokuje jog: stroj bezi (R=1), neni v referenci (H=0), u osy A nasazen nastavec (BR=1).
    Bezpecny rezim + otevrena dvirka (SA=1, D=1) -> rychlost max 1000 mm/min.

  Knihovna: U8g2 (Spravce knihoven -> "U8g2" od oliver)
*/

#include <Arduino.h>
#include <HID.h>
#include <Wire.h>
#include <U8g2lib.h>

// ======================= NASTAVENI =======================
// --- piny ---
const uint8_t PIN_ENC_A = 0;     // RX1  (preruseni INT2)
const uint8_t PIN_ENC_B = 1;     // TX0  (preruseni INT3)
// I2C displej: SDA = 2, SCL = 3 (pevne dane hardwarem)
const uint8_t PIN_AXIS[5] = {4, 5, 6, 7, 8};      // volic os: poloha 1..5 = OFF, X, Y, Z, A
const uint8_t PIN_STEP[4] = {9, 10, 16, 14};      // volic kroku: poloha 1..4 = 0.001, 0.01, 0.1, 1
const uint8_t PIN_MODE = 15;                      // prepinac rezimu: sepnuto na GND = C500

// --- kolecko ---
const int8_t ENC_COUNTS_PER_DETENT = 4;  // MPG 100 pulsu/ot.: 4 hrany na jedno cvaknuti
const bool   ENC_REVERSE = false;        // true = otocit smer kolecka

// --- displej ---
const bool   DISPLAY_FLIP = true;        // piny displeje miri dolu k volicum -> obraz otocit o 180 st.

// --- C500 (Grbl) ---
const float  C500_FEED_MIN = 50.0;       // mm/min
const float  C500_FEED_MAX = 3000.0;     // mm/min
const float  C500_FEED_SAFE = 1000.0;    // mm/min pri SA=1 a D=1 (jako Nest Studio)
// poradi priznaku v poli MS stavoveho hlaseni C500 (index = pozice znaku)
enum { MS_R = 2, MS_D = 4, MS_H = 7, MS_BR = 11, MS_SA = 32 };
const uint16_t C500_BATCH_MS = 30;       // jak casto se posilaji nasbirana cvaknuti
// ==========================================================

// kody WHB04B
enum : uint8_t { AX_OFF = 0x06, AX_X = 0x11, AX_Y = 0x12, AX_Z = 0x13, AX_A = 0x14 };
static const uint8_t AXIS_CODE[5] = {AX_OFF, AX_X, AX_Y, AX_Z, AX_A};
static const uint8_t STEP_CODE[4] = {0x0D, 0x0E, 0x0F, 0x10};
static const float   STEP_MM[4]   = {0.001f, 0.01f, 0.1f, 1.0f};

// ---------------------------------------------------------------------------
//  USB HID rozhrani WHB04B (vlastni modul: standardni knihovna HID neumi SET_REPORT)
// ---------------------------------------------------------------------------
static const uint8_t whbReportDesc[] PROGMEM = {
  // kolekce 1 (Windows: col01): vstupni report ID 4 = tlacitka, voliče, kolecko
  0x06, 0x00, 0xFF,       // Usage Page (Vendor 0xFF00)
  0x09, 0x01,             // Usage (1)
  0xA1, 0x01,             // Collection (Application)
  0x85, 0x04,             //   Report ID (4)
  0x09, 0x01,             //   Usage (1)
  0x15, 0x00,             //   Logical Minimum (0)
  0x26, 0xFF, 0x00,       //   Logical Maximum (255)
  0x75, 0x08,             //   Report Size (8)
  0x95, 0x07,             //   Report Count (7)
  0x81, 0x02,             //   Input (Data,Var,Abs)
  0xC0,                   // End Collection
  // kolekce 2 (Windows: col02): feature report ID 6 = data pro displej
  0x06, 0x00, 0xFF,
  0x09, 0x02,
  0xA1, 0x01,
  0x85, 0x06,             //   Report ID (6)
  0x09, 0x02,
  0x15, 0x00,
  0x26, 0xFF, 0x00,
  0x75, 0x08,
  0x95, 0x07,             //   7 bajtu
  0xB1, 0x02,             //   Feature (Data,Var,Abs)
  0xC0
};

// data z Controlleru (plni se v preruseni USB)
volatile uint8_t dispRaw[21];
volatile uint8_t dispPart = 0;
volatile bool    dispNew = false;

class WHB04Hid : public PluggableUSBModule {
public:
  WHB04Hid() : PluggableUSBModule(1, 1, epType) {
    epType[0] = EP_TYPE_INTERRUPT_IN;
    PluggableUSB().plug(this);
  }
  int send(const uint8_t *d, uint8_t len) {
    return USB_Send(pluggedEndpoint | TRANSFER_RELEASE, d, len);
  }
  uint8_t lastInput[8] = {0x04, 0, 0, 0, 0x0D, AX_OFF, 0, 0};

protected:
  int getInterface(uint8_t *interfaceCount) override {
    *interfaceCount += 1;
    HIDDescriptor d = {
      D_INTERFACE(pluggedInterface, 1, USB_DEVICE_CLASS_HUMAN_INTERFACE, HID_SUBCLASS_NONE, HID_PROTOCOL_NONE),
      D_HIDREPORT(sizeof(whbReportDesc)),
      D_ENDPOINT(USB_ENDPOINT_IN(pluggedEndpoint), USB_ENDPOINT_TYPE_INTERRUPT, USB_EP_SIZE, 0x01)
    };
    return USB_SendControl(0, &d, sizeof(d));
  }
  int getDescriptor(USBSetup &setup) override {
    if (setup.bmRequestType != REQUEST_DEVICETOHOST_STANDARD_INTERFACE) return 0;
    if (setup.wValueH != HID_REPORT_DESCRIPTOR_TYPE) return 0;
    if (setup.wIndex != pluggedInterface) return 0;
    return USB_SendControl(TRANSFER_PGM, whbReportDesc, sizeof(whbReportDesc));
  }
  bool setup(USBSetup &setup) override {
    if (pluggedInterface != setup.wIndex) return false;
    uint8_t request = setup.bRequest;
    uint8_t requestType = setup.bmRequestType;
    if (requestType == REQUEST_DEVICETOHOST_CLASS_INTERFACE) {
      if (request == HID_GET_REPORT) {
        if (setup.wValueH == HID_REPORT_TYPE_INPUT) {
          USB_SendControl(0, lastInput, 8);
        } else {
          uint8_t z[8] = {setup.wValueL, 0, 0, 0, 0, 0, 0, 0};
          USB_SendControl(0, z, 8);
        }
        return true;
      }
      if (request == HID_GET_PROTOCOL) { uint8_t p = 1; USB_SendControl(0, &p, 1); return true; }
      if (request == HID_GET_IDLE)     { uint8_t i = 0; USB_SendControl(0, &i, 1); return true; }
    }
    if (requestType == REQUEST_HOSTTODEVICE_CLASS_INTERFACE) {
      if (request == HID_SET_PROTOCOL || request == HID_SET_IDLE) return true;
      if (request == HID_SET_REPORT) {
        uint8_t buf[8] = {0};
        uint16_t len = setup.wLength;
        if (len > sizeof(buf)) len = sizeof(buf);
        USB_RecvControl(buf, len);
        // buf[0] = ID 6, dal 7 bajtu. Prvni ze tri paketu zacina FE FD FE.
        const uint8_t *p = (buf[0] == 0x06) ? buf + 1 : buf;
        if (p[0] == 0xFE && p[1] == 0xFD) dispPart = 0;
        if (dispPart < 3) {
          for (uint8_t i = 0; i < 7; i++) dispRaw[dispPart * 7 + i] = p[i];
          dispPart++;
          if (dispPart == 3) dispNew = true;
        }
        return true;
      }
    }
    return false;
  }
private:
  uint8_t epType[1];
};

WHB04Hid whb;

// ---------------------------------------------------------------------------
//  Kolecko (kvadraturni enkoder, preruseni na obou kanalech)
// ---------------------------------------------------------------------------
volatile int16_t encCount = 0;
volatile uint8_t encState = 0;
static const int8_t QDEC[16] = {0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1, -1, 0};

void encIsr() {
  uint8_t s = (digitalRead(PIN_ENC_A) << 1) | digitalRead(PIN_ENC_B);
  encCount += QDEC[(encState << 2) | s];
  encState = s;
}

int16_t takeDetents() {
  static int16_t rest = 0;
  noInterrupts();
  int16_t c = encCount; encCount = 0;
  interrupts();
  rest += ENC_REVERSE ? -c : c;
  int16_t d = rest / ENC_COUNTS_PER_DETENT;
  rest -= d * ENC_COUNTS_PER_DETENT;
  return d;
}

// ---------------------------------------------------------------------------
//  Volice a prepinac rezimu (s odrusenim)
// ---------------------------------------------------------------------------
int8_t readPos(const uint8_t *pins, uint8_t n) {        // -1 = zadna poloha (mezi polohami)
  int8_t found = -1;
  for (uint8_t i = 0; i < n; i++)
    if (digitalRead(pins[i]) == LOW) { if (found >= 0) return -1; found = i; }
  return found;
}

struct Debounce {
  int8_t stable = -2, cand = -2; uint32_t t = 0;
  bool update(int8_t raw, uint16_t ms = 20) {
    if (raw != cand) { cand = raw; t = millis(); return false; }
    if (cand != stable && millis() - t >= ms) { stable = cand; return true; }
    return false;
  }
};

Debounce dbAxis, dbStep, dbMode;
uint8_t axisIdx = 0;     // 0 = OFF, 1..4 = X, Y, Z, A
uint8_t stepIdx = 0;     // 0..3
bool    modeC500 = false;

// ---------------------------------------------------------------------------
//  Displej
// ---------------------------------------------------------------------------
U8G2_SSD1306_128X64_NONAME_1_HW_I2C oled(DISPLAY_FLIP ? U8G2_R2 : U8G2_R0, U8X8_PIN_NONE);

int32_t pos4[4] = {0, 0, 0, 0};   // poloha os v desetitisicinach mm (X, Y, Z, A)
bool    havePos = false;
bool    msKnown = false, msRun = false, msHomed = true, msBrush = false, msSafeDoor = false;   // stav C500 z pole MS
bool    dispDirty = true;

void parseControllerDisplay() {
  uint8_t d[21];
  noInterrupts();
  for (uint8_t i = 0; i < 21; i++) d[i] = dispRaw[i];
  dispNew = false;
  interrupts();
  // FE FD FE flags | 3x (uint16 cela cast, uint16 zlomek*10000 + znamenko v bitu 15) | posuv | otacky
  for (uint8_t k = 0; k < 3; k++) {
    uint16_t ip = d[4 + k * 4] | (d[5 + k * 4] << 8);
    uint16_t fr = d[6 + k * 4] | (d[7 + k * 4] << 8);
    int32_t v = (int32_t)ip * 10000L + (fr & 0x7FFF);
    if (fr & 0x8000) v = -v;
    // Controller posila XYZ, je-li zvolena osa A, posila ABC (A na prvnim miste)
    if (axisIdx == 4) { if (k == 0) pos4[3] = v; }
    else pos4[k] = v;
  }
  havePos = true;
  dispDirty = true;
}

// formatovani hodnoty na pocet desetinnych mist podle kroku
void formatValue(int32_t v4, uint8_t decimals, char *out) {
  static const int32_t DIV[5] = {10000, 1000, 100, 10, 1};
  int32_t q = DIV[decimals];
  bool neg = v4 < 0;
  int32_t a = neg ? -v4 : v4;
  a = (a + q / 2) / q;                      // zaokrouhleni
  int32_t scale = 1; for (uint8_t i = 0; i < decimals; i++) scale *= 10;
  int32_t ip = a / scale, fp = a % scale;
  char *p = out;
  if (neg && a != 0) *p++ = '-';
  ltoa(ip, p, 10); p += strlen(p);
  if (decimals) {
    *p++ = '.';
    for (int8_t i = decimals - 1; i >= 0; i--) { p[i] = '0' + fp % 10; fp /= 10; }
    p += decimals;
  }
  *p = 0;
}

void drawDisplay() {
  if (axisIdx == 0) { oled.setPowerSave(1); return; }      // OFF: displej uplne vypnuty
  oled.setPowerSave(0);
  static const char AXL[5] = {' ', 'X', 'Y', 'Z', 'A'};
  char val[16];
  uint8_t dec = 3 - stepIdx;                               // .001 -> 3, .01 -> 2, .1 -> 1, 1 -> 0
  bool show = havePos;
  if (show) formatValue(pos4[axisIdx - 1], dec, val);
  else strcpy(val, "----");
  // nejvetsi pismo, do ktereho se vejde nejdelsi mozna hodnota pro dany krok
  static const char *WIDEST[4] = {"-888.888", "-888.88", "-888.8", "-8888"};
  const uint8_t *fonts[3] = {u8g2_font_logisoso32_tn, u8g2_font_logisoso24_tn, u8g2_font_logisoso18_tn};
  const uint8_t *f = fonts[2];
  for (uint8_t i = 0; i < 3; i++) {
    oled.setFont(fonts[i]);
    if (oled.getStrWidth(WIDEST[stepIdx]) <= 104) { f = fonts[i]; break; }
  }
  char ax[2] = {AXL[axisIdx], 0};
  oled.firstPage();
  do {
    oled.setFont(u8g2_font_logisoso22_tr);
    oled.drawStr(0, 43, ax);
    if (modeC500) oled.drawBox(0, 47, 14, 3);              // znacka rezimu C500 pod pismenem osy
    if (modeC500 && msKnown && !msHomed) {                 // C500 neni v referenci -> kolecko blokovane
      oled.setFont(u8g2_font_logisoso22_tr);
      oled.drawStr(127 - oled.getStrWidth("REF"), 43, "REF");
    } else {
      oled.setFont(f);
      uint8_t h = oled.getAscent();
      oled.drawStr(127 - oled.getStrWidth(val), 32 + h / 2, val);
    }
  } while (oled.nextPage());
}

// ---------------------------------------------------------------------------
//  Rezim C500: Grbl jog pres seriovy port + prijem stavovych hlaseni
// ---------------------------------------------------------------------------
char rx[96]; uint8_t rxLen = 0;
int32_t wco4[4] = {0, 0, 0, 0};

bool parseFloatList(const char *s, int32_t *out, uint8_t maxn) {
  uint8_t n = 0;
  while (*s && n < maxn) {
    char *end;
    double v = strtod(s, &end);
    if (end == s) break;
    out[n++] = (int32_t)(v * 10000.0 + (v >= 0 ? 0.5 : -0.5));
    s = end;
    if (*s == ',') s++; else break;
  }
  return n >= 3;
}

void handleGrblLine(const char *line) {
  if (line[0] != '<') return;
  const char *ms = strstr(line, "MS:");
  if (ms) {
    ms += 3;
    char f[48]; uint8_t n = 0;
    while (n < sizeof(f) && (ms[n] == '0' || ms[n] == '1')) { f[n] = ms[n]; n++; }
    if (n > MS_SA) {
      msKnown = true;
      bool homed = f[MS_H] == '1';
      if (homed != msHomed) dispDirty = true;
      msRun = f[MS_R] == '1'; msHomed = homed; msBrush = f[MS_BR] == '1';
      msSafeDoor = f[MS_SA] == '1' && f[MS_D] == '1';
    }
  }
  const char *w = strstr(line, "WCO:");
  if (w) parseFloatList(w + 4, wco4, 4);
  int32_t p[4] = {0, 0, 0, 0};
  const char *wp = strstr(line, "WPos:");
  if (wp && parseFloatList(wp + 5, p, 4)) {
    for (uint8_t i = 0; i < 4; i++) pos4[i] = p[i];
  } else {
    const char *mp = strstr(line, "MPos:");
    if (!(mp && parseFloatList(mp + 5, p, 4))) return;
    for (uint8_t i = 0; i < 4; i++) pos4[i] = p[i] - wco4[i];
  }
  havePos = true; dispDirty = true;
}

void pollSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (rxLen) { rx[rxLen] = 0; if (modeC500) handleGrblLine(rx); rxLen = 0; }
    } else if (rxLen < sizeof(rx) - 1) rx[rxLen++] = c;
    else rxLen = 0;
  }
}

bool c500JogAllowed() {
  if (!msKnown) return true;                               // bez stavu stroje rozhodne most / stroj
  if (msRun || !msHomed) return false;
  if (axisIdx == 4 && msBrush) return false;
  return true;
}

void c500Jog(int16_t detents) {
  if (!Serial || axisIdx == 0 || detents == 0 || !c500JogAllowed()) return;
  float dist = detents * STEP_MM[stepIdx];
  float feed = fabs(dist) * 60000.0f / C500_BATCH_MS;      // pohyb dobehne zhruba do dalsi davky
  float fmax = msSafeDoor ? C500_FEED_SAFE : C500_FEED_MAX;
  if (feed < C500_FEED_MIN) feed = C500_FEED_MIN;
  if (feed > fmax) feed = fmax;
  char num[16];
  dtostrf(dist, 1, 3, num);
  // stejny tvar jako Nest Studio: $J=G21G91X<d>Y0Z0F<f>, pro A: $J=G21G91X0Y0A<d>F<f>
  Serial.print(F("$J=G21G91"));
  switch (axisIdx) {
    case 1: Serial.print('X'); Serial.print(num); Serial.print(F("Y0Z0")); break;
    case 2: Serial.print(F("X0Y")); Serial.print(num); Serial.print(F("Z0")); break;
    case 3: Serial.print(F("X0Y0Z")); Serial.print(num); break;
    case 4: Serial.print(F("X0Y0A")); Serial.print(num); break;
  }
  Serial.print('F');
  Serial.println((long)feed);
}

void c500Cancel() { if (Serial) Serial.write((uint8_t)0x85); }   // Grbl: zruseni jogu

// ---------------------------------------------------------------------------
//  Odeslani reportu WHB04B
// ---------------------------------------------------------------------------
void sendWhb(int8_t delta) {
  uint8_t r[8];
  r[0] = 0x04;
  r[1] = (uint8_t)random(256);
  r[2] = 0; r[3] = 0;                                      // tlacitka nejsou
  r[4] = STEP_CODE[stepIdx];
  r[5] = modeC500 ? (uint8_t)AX_OFF : AXIS_CODE[axisIdx];           // v rezimu C500 Controller nic nepohne
  r[6] = (uint8_t)delta;
  r[7] = 0;                                                // CRC Controller nekontroluje
  memcpy(whb.lastInput, r, 8);
  whb.send(r, 8);
}

// ---------------------------------------------------------------------------
void setup() {
  pinMode(PIN_ENC_A, INPUT_PULLUP);
  pinMode(PIN_ENC_B, INPUT_PULLUP);
  for (uint8_t i = 0; i < 5; i++) pinMode(PIN_AXIS[i], INPUT_PULLUP);
  for (uint8_t i = 0; i < 4; i++) pinMode(PIN_STEP[i], INPUT_PULLUP);
  pinMode(PIN_MODE, INPUT_PULLUP);
  encState = (digitalRead(PIN_ENC_A) << 1) | digitalRead(PIN_ENC_B);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), encIsr, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_B), encIsr, CHANGE);
  Serial.begin(115200);
  oled.setBusClock(400000);
  oled.begin();
  oled.setContrast(160);
}

void loop() {
  static uint32_t tScan = 0, tSend = 0, tBatch = 0, tDisp = 0;
  uint32_t now = millis();

  if (now - tScan >= 5) {
    tScan = now;
    int8_t a = readPos(PIN_AXIS, 5), s = readPos(PIN_STEP, 4);
    int8_t m = digitalRead(PIN_MODE) == LOW;
    bool changed = false;
    if (dbAxis.update(a) && dbAxis.stable >= 0) { axisIdx = dbAxis.stable; changed = true; }
    if (dbStep.update(s) && dbStep.stable >= 0) { stepIdx = dbStep.stable; changed = true; }
    if (dbMode.update(m, 50)) { modeC500 = dbMode.stable; havePos = false; msKnown = false; changed = true; }
    if (changed) {
      takeDetents();                                       // co se natocilo pri prepinani, zahodit
      if (modeC500) c500Cancel();
      sendWhb(0);
      dispDirty = true;
    }
  }

  // kolecko
  if (!modeC500) {
    if (now - tSend >= 10) {
      tSend = now;
      int16_t d = takeDetents();
      if (axisIdx == 0) d = 0;                             // OFF: kolecko nic nedela
      if (d) {
        while (d) {                                        // jog jde v int8
          int8_t part = d > 127 ? 127 : (d < -127 ? -127 : d);
          sendWhb(part); d -= part;
        }
      }
    }
  } else if (now - tBatch >= C500_BATCH_MS) {
    tBatch = now;
    c500Jog(takeDetents());
  }

  // pravidelne hlaseni stavu (Controller tak zna polohu volicu i po pripojeni)
  static uint32_t tKeep = 0;
  if (now - tKeep >= 250) { tKeep = now; sendWhb(0); }

  if (dispNew && !modeC500) parseControllerDisplay();
  pollSerial();

  if (dispDirty && now - tDisp >= 80) {
    tDisp = now; dispDirty = false;
    drawDisplay();
  }
}
