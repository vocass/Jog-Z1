# Zapojeni jog ovladace (Arduino Pro Micro 5 V)

| Pro Micro pin | Kam | Poznamka |
|---|---|---|
| VCC | MPG Vcc, OLED VCC | 5 V z USB |
| GND | MPG 0V, OLED GND, spolecne vyvody obou volicu, prepinac rezimu | |
| RX1 (D0) | MPG A | preruseni |
| TX0 (D1) | MPG B | preruseni |
| 2 (SDA) | OLED SDA | |
| 3 (SCL) | OLED SCL | |
| 4 | volic os - poloha 1 (OFF) | |
| 5 | volic os - poloha 2 (X) | |
| 6 | volic os - poloha 3 (Y) | |
| 7 | volic os - poloha 4 (Z) | |
| 8 | volic os - poloha 5 (A) | polohy 6-8 nezapojene |
| 9 | volic kroku - poloha 1 (.001) | |
| 10 | volic kroku - poloha 2 (.01) | |
| 16 | volic kroku - poloha 3 (.1) | |
| 14 | volic kroku - poloha 4 (1) | polohy 5-8 nezapojene |
| 15 | prepinac rezimu (druhy vyvod na GND) | sepnuto = C500 |
| USB | kabel k tabletu | VBUS cerveny, D- bily, D+ zeleny, GND cerny |

Volne zustavaji A0-A3 (18-21) a RAW.
MPG: zapojuje se jen prvni svorkovnice (A, B, 0V, Vcc); druha (A, B - invertovane) zustava volna.
Vsechny vstupy maji vnitrni pull-up, externi rezistory nejsou potreba.
